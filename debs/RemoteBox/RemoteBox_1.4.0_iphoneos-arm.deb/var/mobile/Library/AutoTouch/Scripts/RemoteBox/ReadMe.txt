Video Demo: https://youtu.be/QNwMdhOIk58


# What is RemoteBox #

RemoteBox is a tweak/script that uses DropBox so you can remotly control your devices. Multiple devices are supported on the same DropBox account. It is highly recommended reading this readme.



# So what can it do #

RemoteBox can start any AutoTouch script .lua, .at, .ate files from a remote jailbroken or non-jailbroken device. All your script names will be shown in DropBox. You can also issue terminal commands with root accsess, results from commands will be uploaded back to DropBox. Passcode on lock screen has to be disabled to be able to run AutoTouch scripts/bots. For terminal commands there is no need to disable passcode.



# How to setup #

You need to create a DropBox app, the name of the app you choose will be the name of the folder that you will be using.

1. Create DropBox app
a) Visit: https://www.dropbox.com/developers/apps/
b) Create app
c) Sign in if not already or create an account (its free)
d) Dropbox api
e) App folder – Access to a single folder created specifically for your app.
f) App name: AutoTouch Remote (example name)
g) Create app
h) Generated access token
i) Copy token

2. Open AutoTouch app, goto RemoteBox folder. Press the play button beside Setup.ate

3. Paste in your access token

4. Press the "Setup" button, you should get an alert saying Setup Successful. If you dont try reset button and try again. Make sure to copy and paste access token fully.

5. Go on to your DropBox account and you should see the new folder (app) and in that folder another folder with your serial number as the folder name.

6. Done!




# files and folders #

RunScript.txt - run command and AutoTouch Scripts

scriptList.txt - list of AutoTouch scripts from that device

cmdResults - results returned back from commands sent to device (excluding AT functions)

AutoTouch Logs - everytime you run an AutoTouch Script it will log if it worked or not or request ATlog()





# Usage #

Open RunScript.txt and press the (I) to be able to write in the text file (using DropBox app has an I) this is where you run the functions. After pressing save a few seconds later the text will be removed.

COMMAND# - run terminal commands

#!/bin/bash - run bash scripts

scriptList() - updates scriptList.txt

Respring() - restart SpringBoard

Deviceinfo() - useful device information

ATstart(script.ate) - run AutoTouch script

ATlog() - view AutoTouch Log

ATlogclear() - clears AutoTouch Log

ATstop() - stops all AutoTouch running scripts

ATupload(myScript.lua) or ATupload(folder/myScript.lua) - uploads AutoTouch script.

Screenshot() - take screenshot on remote device and view in DropBox.

Upload() - Upload any file from device to DropBox App/Upload.

Download() - Download any file from Upload folder to Device.

DownloadLink() - Download any file via shared link to AutoTouch Script folder

ScreenRecord() - Take a screen recording of remote device. (Activator requires)



# Descriptions #


COMMAND#

Open RunScript.txt and press the (I) to be able to write in the text file (using DropBox app has an I). Commands have to start with this COMMAND# so for example to list all cydia packages on your device you would save this into RunScript.txt COMMAND#dpkg -l After some seconds goto the folder cmdResults, you will have a reply back from the device in timeanddate.txt



#!/bin/bash

Paste full bash script with #!/bin/bash at the very top of RunScipt.txt and Save. After some seconds goto the folder cmdResults, you will have a reply back from the device in timeanddate.txt



scriptList()

Save scriptlist() into RunScript.txt, scripts will be updated on to DropBox.



Respring()

Save Respring() into RunScript.txt, target device will Restart SpringBoard.



Deviceinfo()

Save Deviceinfo() into RunScript.txt, you will have a reply back from the device in timeanddate.txt with some very useful device information. Battery percentage, charging information and some wifi connection information.



ATstart()

Open scriptList.txt to view scripts avalible on that device simply copy the script you want to run. Paste the script name between the parentheses (), ATstart()

example: ATstart(script.ate) or ATstart(myFolder/script.lua)

After some seconds go to the folder AutoTouch Logs, you will have a reply back from the device in timeanddate.txt



ATlog()

Save ATlog() into RunScript.txt, target device will upload AutoTouch log to the AutoTouch log folder.



ATlogclear()

Save ATlogclear() into RunScript.txt, AutoTouch log will be cleared on target device.



ATupload()

Open scriptList.txt to view scripts avalible on that device simply copy the script you want to upload. Paste the script name between the parentheses (), ATupload()

example: ATupload(script.lua) or ATupload(myFolder/script.lua)

After some seconds goto the folder Script Uploads, you will find your script from the device. (ATupload() supports .lua files only)



Screenshot()

Save Screenshot() to runScript.txt a screenshot from remote device will be uploaded to DropBox also a message will be sent to cmdResults folder.
note: WiFI and Web server switch must be on in the AutoTouch app!


Upload()

Save Upload(myscript.at) or Upload(path/myfile) to runScript.txt file or folder will be uploaded to DropBox app/Upload Default path is /var/mobile/Library/AutoTouch/Scripts


Download()

Save Download(myscript.at) or Download(destination/path/myfile) to runScript.txt file or folder will be Downloaded to your device. Only files in App/Upload folder can be downloaded. Default destination is /var/mobile/Library/AutoTouch/Scripts


DownloadLink()

Save DownloadLink(url) to runScript.txt the file or folder from the link will be downloaded  
to /var/mobile/Library/AutoTouch/Scripts


ScreenRecord()

Save ScreenRecord(15) to runScript.txt 15 is the seconds you want the screen record to take. The recording will be uploaded to ScreenRecords folder in your Dropbox App.
ScreenRecord() without the seconds will default to 10 seconds. Activator is required for ScreenRecord.


# Recommendation #

It is recommended to turn on “Web Server” and “Keep AutoTouch Awake” in AutoTouch app > Settings.



# Support #

Discord: https://discord.gg/GUXu4uZ












